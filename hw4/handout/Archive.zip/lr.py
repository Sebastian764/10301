import numpy as np
import argparse

def sigmoid(x : np.ndarray):
    """
    Implementation of the sigmoid function.

    Parameters:
        x (np.ndarray): Input np.ndarray.

    Returns:
        An np.ndarray after applying the sigmoid function element-wise to the
        input.
    """
    e = np.exp(x)
    return e / (1 + e)

# def deriv_J_theta_j(theta : np.ndarray, X : np.ndarray, y : int, theta_X_dot : dict, j : int) -> float:
#     deriv = 0
#     if len(X) == 0:
#         print("X has empty vector values")

#     adjusted_x = [val[j] for val in X] # array of x^i_j
#     for i in range(len(adjusted_x)):
#         if X[i] not in theta_X_dot:
#             theta_X_dot[X[i]] = np.dot(theta, X[i]) # x^i
#         deriv += adjusted_x[i] * (sigmoid(theta_X_dot[X[i]]) - y[i])
#     return deriv / len(X)


def train(
    theta : np.ndarray, # shape (D,) where D is feature dim
    X : np.ndarray,     # shape (N, D) where N is num of examples feature vector
    y : np.ndarray,     # shape (N,)
    num_epoch : int, 
    learning_rate : float
) -> None:
    # np.insert(x, 0, 1)

    for epoch in range(num_epoch):
        for i in range(len(X)):
            error = sigmoid(np.dot(X[i], theta)) - y[i]
            for j in range(len(theta)):
                gradient = error * X[i][j]
                # update weights
                theta[j] = theta[j] - learning_rate * gradient
    
    

def predict(
    theta : np.ndarray,
    X : np.ndarray
) -> np.ndarray:
    predictions = np.zeros(len(X))
    for i in range(len(X)):
        thetaT_X = np.dot(theta, X[i])
        y_hat = 1 if sigmoid(thetaT_X) >= 0.5 else 0
        predictions[i] = y_hat

    return predictions

def compute_error(
    y_pred : np.ndarray, 
    y : np.ndarray
) -> float:
    # # TODO: Implement `compute_error` using vectorization
    # num_diff = 0
    # for i in range(len(y)):
    #     if y_pred[i] != y[i]:
    #         num_diff += 1
    # return len(y) / num_diff
    return np.mean(y_pred != y)
    
def load_formatted_data(file_path:str) -> np.ndarray:
    # Load the data from the file in format label\tfeature1\tfeature2\t...\tfeatureN\n
    # Return the labels and features as separate numpy arrays in tuple.
    labels = []
    features = []
    with open(file_path, 'r', encoding='utf-8') as file:
        for line in file:
            components = line.split('\t')

            labels.append(components[0])

            features_vector = ([float(val) for val in components[1:]])
            features.append(features_vector)
    
    labels = np.array(labels, dtype=float)
    features = np.array(features)

    return (labels, features)

def write_metrics(file_path:str, train_error:float, test_error:float):
    # Write metrics to a file
    with open(file_path, 'w') as file:
        file.write(f"error(train): {train_error:.6f}\n")
        file.write(f"error(test): {test_error:.6f}\n")

def write_predictions(file_path:str, predictions:np.ndarray):
    # Write predictions to a file
    with open(file_path, 'w') as file:
        for prediction in predictions:
            file.write(f"{prediction}\n")

if __name__ == '__main__':
    # This takes care of command line argument parsing for you!
    # To access a specific argument, simply access args.<argument name>.
    # For example, to get the learning rate, you can use `args.learning_rate`.
    parser = argparse.ArgumentParser()
    parser.add_argument("train_input", type=str, help='path to formatted training data')
    parser.add_argument("validation_input", type=str, help='path to formatted validation data')
    parser.add_argument("test_input", type=str, help='path to formatted test data')
    parser.add_argument("train_out", type=str, help='file to write train predictions to')
    parser.add_argument("test_out", type=str, help='file to write test predictions to')
    parser.add_argument("metrics_out", type=str, help='file to write metrics to')
    parser.add_argument("num_epoch", type=int, 
                        help='number of epochs of stochastic gradient descent to run')
    parser.add_argument("learning_rate", type=float,
                        help='learning rate for stochastic gradient descent')
    args = parser.parse_args()

    # Load the data
    train_labels, train_features = load_formatted_data(args.train_input)
    validation_labels, validation_features = load_formatted_data(args.validation_input)
    test_labels, test_features = load_formatted_data(args.test_input)

    # Correctly augment features with intercept term
    train_features = np.insert(train_features, 0, 1, axis=1)
    validation_features = np.insert(validation_features, 0, 1, axis=1)
    test_features = np.insert(test_features, 0, 1, axis=1)

    # Initialize theta after feature augmentation
    theta = np.zeros(train_features.shape[1])  # Correct dimensionality

    # Train the model
    train(theta, train_features, train_labels.astype(int), args.num_epoch, args.learning_rate)

    # Make predictions
    train_predictions = predict(theta, train_features)
    validation_predictions = predict(theta, validation_features)
    test_predictions = predict(theta, test_features)

    # Compute and write errors
    train_error = compute_error(train_predictions, train_labels.astype(int))
    validation_error = compute_error(validation_predictions, validation_labels.astype(int))
    test_error = compute_error(test_predictions, test_labels.astype(int))
    write_metrics(args.metrics_out, train_error, test_error)

    # Write predictions
    write_predictions(args.train_out, train_predictions)
    write_predictions(args.test_out, test_predictions)


